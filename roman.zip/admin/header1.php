<div class="col-sm-3 col-md-2 sidebar">
  		<ul class="nav nav-sidebar">
  			<li class="active"><a href="#">MENU UTAMA <span class="sr-only">(current)</span></a></li>
  			<li><a href="?module=home"><i class="glyphicon glyphicon-home"></i> Home</a></li>
            <li><a href="?module=siswa"><i class="glyphicon glyphicon-user"></i> Data Alumni</a></li>
            <li><a href="?module=jurusan"><i class="glyphicon glyphicon-th"></i> Data Jurusan</a></li>
            <li><a href="?module=lowongan"><i class="glyphicon glyphicon-th"></i> Data Lowongan</a></li>
            <li><a href="?module=users"><i class="glyphicon glyphicon-list"></i> Data Users</a></li>
  		</ul>
  			</div>